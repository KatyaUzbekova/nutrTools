//
//  IncomingMessages.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 28.05.2021.
//

import Foundation

struct IncomingMessages {
    let message: String
    let chtaId: CLong
    let messageType: String
    let token: String
}
