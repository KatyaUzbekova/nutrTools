//
//  config.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 12.04.2021.
//

import Foundation
let urlToImage = "https://nutrtools.info:443/images/"
