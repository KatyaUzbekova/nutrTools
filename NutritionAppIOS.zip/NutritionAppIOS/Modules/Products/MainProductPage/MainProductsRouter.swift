//
//  MainProductsRouter.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 14.06.2021.
//

import Foundation


protocol MainProductsRouterProtocol: class {
}

class MainProductsRouter: MainProductsRouterProtocol {
    
}
