//
//  MainProductsConfigurator.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 14.06.2021.
//

import Foundation

protocol MainProductsConfiguratorProtocol: class {
}

class MainProductsConfigurator: MainProductsConfiguratorProtocol {
    
}
