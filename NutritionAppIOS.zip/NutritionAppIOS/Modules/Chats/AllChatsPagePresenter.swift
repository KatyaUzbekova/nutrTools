//
//  AllChatsPagePresenter.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 11.05.2021.
//

import Foundation

class AllChatsPagePresenter: AllChatsPagePresenterProtocol {
    
}
