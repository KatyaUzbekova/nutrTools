//
//  Protocols.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 11.05.2021.
//

import Foundation

protocol AllChatsPageViewControllerProtocol: class {
    func setupViewDelegates()
}


protocol AllChatsPagePresenterProtocol: class {
    
}
