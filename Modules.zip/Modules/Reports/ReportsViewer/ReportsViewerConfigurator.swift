//
//  ReportsViewerConfigurator.swift
//  NutritionAppIOS
//
//  Created by Екатерина Узбекова on 09.04.2021.
//

import Foundation
